Islamiyat user-supplied offline audio package — 21 November 2026

1. Ali Ahmad Mulla: android/app/src/main/res/raw/ali_ahmad_mulla_hq.mp3
   Intended default/top choice for the muezzin list.
2. Abdul Majid Al-Surehi Fajr phrase: android/app/src/main/res/raw/fajr_khayr_min_al_nawm.mp3
   NOT a selectable muezzin. Must play ONLY after complete Fajr adhan and BEFORE Fajr iqama, once per local day, when iqamaMinutes has been set.

Copy these raw assets into the exact project paths on the review branch. Native implementation and tests were committed to GitHub separately. Existing audio must not be removed.

Important: these two audio files were supplied by the user. Audio redistribution/commercial licensing remains unverified.
